package com.fpt.foodapp.interfaces;

import androidx.recyclerview.widget.RecyclerView;

public interface ReViewXoa {

    void itemSwiped(RecyclerView.ViewHolder viewHolder, int direction, int id);


}
