package com.fpt.foodapp.interfaces;

import android.view.View;

public interface ItemClick {
    void itemClick(View view, int position, boolean isLongClick);

}
