package com.example.admin_duan1.interfaces;

import androidx.recyclerview.widget.RecyclerView;

public interface ReViewXoa {

    void itemSwiped(RecyclerView.ViewHolder viewHolder, int direction, int id);


}
