package com.example.admin_duan1.common;

import com.example.admin_duan1.dto.User;

public class Common {
    public static User user;
    public static final String UPDATE ="Update";
    public static final String DELETE ="Delete";
    public static final String CHAP_NHAN ="Chấp Thuận";
    public static final String HUY ="Hủy";
}
