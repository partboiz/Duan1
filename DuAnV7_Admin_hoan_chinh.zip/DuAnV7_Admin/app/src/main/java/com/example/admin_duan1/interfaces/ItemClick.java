package com.example.admin_duan1.interfaces;

import android.view.View;

public interface ItemClick {
    void itemClick(View view, int position, boolean isLongClick);

}
